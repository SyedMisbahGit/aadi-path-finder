
import { ConversationalCounselor } from '@/components/ai/ConversationalCounselor';

const AICounseling = () => {
  return <ConversationalCounselor />;
};

export default AICounseling;
